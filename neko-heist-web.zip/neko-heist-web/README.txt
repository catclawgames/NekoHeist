Neko Heist: website build

Put everything in this folder (including the hidden .nojekyll file) at the root of a GitHub repo,
then turn on Settings > Pages > Deploy from a branch > main / (root).
Your game will be at https://YOUR-NAME.github.io/REPO-NAME/

Online play (accounts, raiding other players' bases, leaderboard): paste your Firebase settings into
firebase-config.js and add YOUR-NAME.github.io to Firebase > Authentication > Settings > Authorized domains.
Without it, the game runs offline against the computer manors.

Before publishing, fill in the [brackets] in privacy.html.
